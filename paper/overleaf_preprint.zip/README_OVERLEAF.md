# Overleaf build instructions (ScrubID preprint)

## Upload
1. Download `overleaf_preprint.zip`.
2. In Overleaf: **New Project → Upload Project** and select the ZIP.

## Compile
- **Main document:** `main.tex`
- **Compiler:** pdfLaTeX
- **Bibliography tool:** BibTeX (Overleaf runs it automatically when needed)

This project is formatted as a **single-column arXiv-style preprint** (11pt) for readability.

If references do not show up after the first compile, click **Recompile** once more.

## Included artifacts (read-only)
This project includes the exact CSV tables and PNG figure that back the paper:
- `artifacts/table_T1.csv`, `artifacts/table_T2.csv`, `artifacts/table_T3.csv`, `artifacts/table_T4.csv`
- `figures/fig_synth.png`

For provenance and reproducibility context (not required to read the paper):
- `artifacts/paper_results_manifest.json`
- `artifacts/spec_00_CANONICAL.md`
