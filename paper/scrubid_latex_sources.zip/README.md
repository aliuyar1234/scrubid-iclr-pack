﻿# ScrubID paper sources (LaTeX)

This bundle contains a self-contained LaTeX source tree for the ScrubID preprint.

## Build (pdfLaTeX + BibTeX)

1. pdflatex main.tex
2. bibtex main
3. pdflatex main.tex
4. pdflatex main.tex

## Online editors

You can upload this ZIP to Overleaf (or any LaTeX editor that supports ZIP import) and compile `main.tex`.
