from __future__ import annotations
import re
from pathlib import Path

SRC_PATH = Path('/mnt/data/gptpro_inputs/paper.md')
OUT_DIR = Path('/mnt/data/overleaf_project/inputs')
OUT_DIR.mkdir(parents=True, exist_ok=True)

src = SRC_PATH.read_text(encoding='utf-8')
lines = src.splitlines()
assert lines[0].startswith('# ')
title = lines[0][2:].strip()
date_match = re.search(r'^Date:\s*(.+)\s*$', src, flags=re.M)
date = date_match.group(1).strip() if date_match else ''

# Drop manual References section
src = src.split('\n## References\n', 1)[0]

# Drop the title line and Date line block
src = re.sub(r'^# .+\n\nDate:\s*.+\n', '', src, flags=re.M)

# Special-case inline code spans that contain non-ASCII math glyphs in the source.
# Replace the full backticked span with a math-formatted LaTeX fragment.
SPECIAL_CODE_SPANS = {
    'ε': '$\\epsilon$',
    'D = (x_0, x_1, …, x_{N-1})': '$D = (x_0, x_1, \\ldots, x_{N-1})$',
    'C ⊆ V': '$C \\subseteq V$',
    'v ∉ C': '$v \\notin C$',
    'D_eval ⊆ D': '$D_{\\mathrm{eval}} \\subseteq D$',
    'J(A, B) = |A ∩ B| / |A ∪ B|': '$J(A,B)=\\frac{|A\\cap B|}{|A\\cup B|}$',
    'A ∪ B': '$A \\cup B$',
    'offset ∈ SEEDS.PAPER_REAL_SEED_OFFSETS': '`offset` $\\in$ `SEEDS.PAPER_REAL_SEED_OFFSETS`',
}

for k, v in SPECIAL_CODE_SPANS.items():
    src = src.replace(f'`{k}`', v)

# Split into abstract and body
m_abs = re.search(r'^## Abstract\s*\n(.*?)\n^## ', src, flags=re.S | re.M)
if not m_abs:
    raise RuntimeError('Could not locate Abstract section')
abstract_md = m_abs.group(1).strip() + '\n'
body_md = src[m_abs.end()-3:].strip() + '\n'

# Replace unicode math operators in non-code content.
# Operator tokens are inserted as spaced math to avoid Pandoc $-delimiter ambiguity.
REPL = {
    '≈': ' $\\approx$ ',
    '≥': ' $\\ge$ ',
    '≤': ' $\\le$ ',
    '∈': ' $\\in$ ',
    '→': ' $\\to$ ',
    '↔': ' $\\leftrightarrow$ ',
    '×': ' $\\times$ ',
    'ε': '$\\epsilon$',
    'τ': '$\\tau$',
    'Δ': '$\\Delta$',
    '⊆': ' $\\subseteq$ ',
    '∩': ' $\\cap$ ',
    '∪': ' $\\cup$ ',
    '…': '\\ldots{}',
}

def protect_and_replace(md: str) -> str:
    out_lines = []
    in_fence = False
    # Protect inline code spans
    code_spans: list[str] = []

    def repl_inline_code(m: re.Match) -> str:
        code_spans.append(m.group(1))
        return f'@@CODE{len(code_spans)-1}@@'

    for line in md.splitlines():
        if line.strip().startswith('```'):
            in_fence = not in_fence
            out_lines.append(line)
            continue
        if in_fence:
            out_lines.append(line)
            continue
        # Extract inline code spans to avoid accidental substitutions inside them
        tmp = re.sub(r'`([^`]+)`', repl_inline_code, line)
        for k, v in REPL.items():
            tmp = tmp.replace(k, v)
        out_lines.append(tmp)

    # Restore inline code spans
    text = '\n'.join(out_lines)
    for idx, c in enumerate(code_spans):
        text = text.replace(f'@@CODE{idx}@@', f'`{c}`')
    return text + '\n'

abstract_md = protect_and_replace(abstract_md)
body_md = protect_and_replace(body_md)

# Inject LaTeX blocks for the tables (T1..T4) from the provided CSVs, and insert the synth figure.

def replace_table_block(md: str, table_heading_prefix: str, table_tex_path: str, caption: str, label: str) -> str:
    # Find the heading line
    lines = md.splitlines()
    out = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith(table_heading_prefix):
            out.append(line)
            # Skip any following markdown table lines starting with '|' until a blank line
            j = i + 1
            while j < len(lines) and lines[j].strip() == '':
                out.append(lines[j])
                j += 1
            # If a markdown table follows, consume it
            if j < len(lines) and lines[j].lstrip().startswith('|'):
                while j < len(lines) and lines[j].lstrip().startswith('|'):
                    j += 1
                # also consume separator lines like '| --- |'
                while j < len(lines) and (lines[j].strip() == '' or lines[j].lstrip().startswith('|')):
                    j += 1
            # Insert LaTeX table block
            out.append('')
            out.append(r'\begin{table*}[t]')
            out.append(r'\centering')
            out.append(r'\scriptsize')
            out.append(r'\setlength{\tabcolsep}{3pt}')
            out.append(r'\renewcommand{\arraystretch}{1.15}')
            out.append(rf'\resizebox{{\textwidth}}{{!}}{{\input{{{table_tex_path}}}}}')
            out.append(rf'\caption{{{caption}}}')
            out.append(rf'\label{{{label}}}')
            out.append(r'\end{table*}')
            out.append('')
            i = j
            continue
        out.append(line)
        i += 1
    return '\n'.join(out) + '\n'

# Insert synth figure near the "Synthetic benchmark results" heading
if '### Synthetic benchmark results' in body_md:
    body_md = body_md.replace(
        '### Synthetic benchmark results\n',
        '### Synthetic benchmark results\n\n'
        '\\begin{figure}[t]\n'
        '\\centering\n'
        '\\includegraphics[width=\\columnwidth]{figures/fig_synth.png}\n'
        '\\caption{Synthetic suite trends (SUITE\\_SYNTH\\_V1).}\n'
        '\\label{fig:synth}\n'
        '\\end{figure}\n\n'
    )
body_md = replace_table_block(
    body_md,
    '#### Table T1',
    'tables/table_T1.tex',
    'Synthetic redundancy sweep on SUITE\_SYNTH\_V1. Metrics are means with 95\\% bootstrap confidence intervals for each setting, and the certificate emission rate in that setting.',
    'tab:t1'
)
body_md = replace_table_block(
    body_md,
    '#### Table T2',
    'tables/table_T2.tex',
    'Real-model case study summary on the in-distribution split (ID) for GPT-2 small under activation patching. Each row aggregates over N=5 suite seeds for the given generator.',
    'tab:t2'
)
body_md = replace_table_block(
    body_md,
    '#### Table T4',
    'tables/table_T4.tex',
    'Real-model case study summary on the out-of-distribution split (OOD) for GPT-2 small under activation patching. Each row aggregates over N=5 suite seeds for the given generator.',
    'tab:t4'
)
body_md = replace_table_block(
    body_md,
    '#### Table T3',
    'tables/table_T3.tex',
    'Sensitivity deltas against a per-suite baseline run. Deltas are computed on aggregate summaries for each variant.',
    'tab:t3'
)

# Inject pipeline TikZ figure after the introduction paragraph that mentions audit certificates
PIPE_FIG = (
    '\n\\begin{figure}[t]\n\\centering\n\\input{figures/pipeline_tikz.tex}\n'
    '\\caption{ScrubID audit pipeline schematic (illustrative).}\n\\label{fig:pipeline}\n\\end{figure}\n'
)
needle = 'ScrubID produces an audit certificate'
if needle in body_md:
    body_md = body_md.replace(needle + '\n', needle + '\n' + PIPE_FIG + '\n', 1)

# Write outputs
(Path('/mnt/data/overleaf_project/inputs/abstract.md')).write_text(abstract_md, encoding='utf-8')
(Path('/mnt/data/overleaf_project/inputs/body.md')).write_text(body_md, encoding='utf-8')
(Path('/mnt/data/overleaf_project/inputs/meta.txt')).write_text(f'title={title}\ndate={date}\n', encoding='utf-8')
print('OK')
